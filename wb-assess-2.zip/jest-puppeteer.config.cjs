module.exports = {
  launch: {
    headless: 'new',
  },
};
